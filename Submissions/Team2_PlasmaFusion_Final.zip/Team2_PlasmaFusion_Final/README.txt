Hello! Thank you for playing PLASMA FUSION!

We recommend you click through the HANDBOOK before playing if it's your first time.
Additionally, PLASMA FUSION contains bright effects that some players may find difficult to handle. If you
fall into this category, please use discretion if you still decide to play!

Again, thank you!